.\adc2.o: adc2.c
.\adc2.o: types.h
.\adc2.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
.\adc2.o: adc_defines.h
.\adc2.o: delays.h
.\adc2.o: types.h
.\adc2.o: adc.h
.\adc2.o: types.h
