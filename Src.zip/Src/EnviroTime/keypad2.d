.\keypad2.o: keypad2.c
.\keypad2.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
.\keypad2.o: types.h
.\keypad2.o: delays.h
.\keypad2.o: types.h
.\keypad2.o: alarm.h
.\keypad2.o: types.h
